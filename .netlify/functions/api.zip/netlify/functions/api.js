var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/api.ts
var api_exports = {};
__export(api_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(api_exports);

// src/challenge-config.json
var challenge_config_default = {
  seasons: [
    {
      id: 1,
      name: "Season 1 (Spring 2026)",
      challenge: {
        title: "100 Websites in 30 Days",
        startDate: "2026-03-24T00:00:00Z",
        endDate: "2026-04-23T23:59:59Z",
        targetCount: 100
      },
      projects: [
        {
          id: 1,
          title: "The Con Archive",
          date: "2026-03-24T17:23:12.000Z",
          url: "https://theconarchive.nealfrazier.tech",
          description: "A grifter wiki. Capturing historical grifters and cons throughout history.",
          tags: [
            "google-ai-studio",
            "netlify"
          ],
          thumbnail: "https://theconarchive.nealfrazier.tech/og-image.png"
        },
        {
          id: 2,
          title: "Mundane Oracle",
          date: "2026-03-24T22:34:13.000Z",
          url: "https://mundaneoracle.nealfrazier.tech",
          description: "The everyday app that makes your trivial decisions using absurdly dramatic cosmic reasoning. Made for the overthinker. Built without overthinking.",
          tags: [
            "google-ai-studio",
            "netlify"
          ],
          thumbnail: "https://mundaneoracle.nealfrazier.tech/og-image.png"
        },
        {
          id: 3,
          title: "OneFocus",
          date: "2026-03-24T22:52:12.000Z",
          url: "https://onefocus.nealfrazier.tech",
          description: "Hyper-minimalist daily focus application. Less is more. Focus on one task at a time, eliminate distractions, and boost your productivity.",
          tags: [
            "google-ai-studio",
            "netlify"
          ],
          thumbnail: "https://onefocus.nealfrazier.tech/og-image.png"
        },
        {
          id: 4,
          title: "DuckDuckDucky",
          date: "2026-03-26T13:05:41.000Z",
          url: "https://duckduckducky.nealfrazier.tech",
          description: "Terminal-inspired React-based editor designed for security researchers and hardware enthusiasts. Provides Duck Scripts for inspiration.",
          tags: [
            "google-ai-studio",
            "netlify"
          ],
          thumbnail: "https://duckduckducky.nealfrazier.tech/og-image.png"
        },
        {
          id: 5,
          title: "Aether",
          date: "2026-03-28T01:23:27.000Z",
          url: "https://aether.nealfrazier.tech",
          description: "Interactive digital consciousness experience \u2014 a highly designed, out-of-the-box web journey.",
          tags: [
            "google-ai-studio",
            "netlify"
          ],
          thumbnail: "https://aether.nealfrazier.tech/og-image.png"
        },
        {
          id: 6,
          title: "Lumina",
          date: "2026-03-28T01:55:06.000Z",
          url: "https://lumina.757tech.pro",
          description: "Helps you design premium websites with ready-made sections, responsive previews, SEO controls, and exportable code.",
          tags: [
            "google-ai-studio",
            "netlify"
          ],
          thumbnail: "https://lumina.757tech.pro/og-image.png"
        },
        {
          id: 7,
          title: "SEO Trend Tool",
          date: "2026-03-28T02:43:08.000Z",
          url: "https://seo-trend-tool.streamlit.app",
          description: "Lightweight keyword opportunity mining from Google Trends, optimized to run on Streamlit Cloud free tier.",
          tags: [
            "streamlit"
          ],
          thumbnail: "https://api.microlink.io?url=https%3A%2F%2Fseo-trend-tool.streamlit.app&screenshot=true&embed=screenshot.url"
        },
        {
          id: 8,
          title: "The Gazette Hub",
          date: "2026-03-28T22:26:18.000Z",
          url: "https://thegazettehub.nealfrazier.tech",
          description: "High-end, modernized newspaper website template and brand management hub.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://thegazettehub.nealfrazier.tech/og-image.png"
        },
        {
          id: 9,
          title: "Conscious Cat Guardianship",
          date: "2026-03-28T23:14:10.000Z",
          url: "https://cats.nealfrazier.tech",
          description: "Rescue-first cat care guide covering behavior, nutrition, breeds, and practical day-to-day feline well-being.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://cats.nealfrazier.tech/og-image.png"
        },
        {
          id: 10,
          title: "Winner Winner Chicken Dinner",
          date: "2026-03-29T04:55:32.000Z",
          url: "https://winnerwinnerchickendinner.nealfrazier.tech",
          description: "Training-focused blackjack web app for faster card-counting skill development.",
          tags: [
            "openai",
            "netlify"
          ],
          thumbnail: "https://winnerwinnerchickendinner.nealfrazier.tech/og-image.png"
        },
        {
          id: 11,
          title: "Hack The World",
          date: "2026-03-29T21:23:57.000Z",
          url: "https://hacktheworld.nealfrazier.tech",
          description: "Hacker-styled Hacker News interface with immersive terminal visuals, threaded comments, and live top/new/ask/show/job feeds.",
          tags: [
            "netlify-hn-api",
            "custom"
          ],
          thumbnail: "https://hacktheworld.nealfrazier.tech/og-image.png"
        },
        {
          id: 12,
          title: "Melt The Machine",
          date: "2026-03-29T22:27:19.000Z",
          url: "https://meltthemachine.nealfrazier.tech",
          description: "Anonymous ICE sighting reporting tool and comprehensive \u201CKnow Your Rights\u201D resource hub. Protect your community.",
          tags: [
            "supabase",
            "google-ai-studio",
            "netlify"
          ],
          thumbnail: "https://meltthemachine.nealfrazier.tech/og-image.png"
        },
        {
          id: 13,
          title: "SF Arcade",
          date: "2026-03-30T02:40:07.000Z",
          url: "https://sf-arcade.nealfrazier.tech",
          description: "Street Fighter Arcade \u2014 retro competitive arena with real-time multiplayer. Modes: Typing Battle, Code Clash, and Arcade Fight.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://sf-arcade.nealfrazier.tech/og-image.png"
        },
        {
          id: 14,
          title: "Thumb Journey",
          date: "2026-03-31T01:15:48.000Z",
          url: "https://thumb-journey.nealfrazier.tech",
          description: "Mobile-first cinematic audio experience. Hold, motion, and parallax transform iconic speeches into tactile rituals.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://thumb-journey.nealfrazier.tech/og-image.png"
        },
        {
          id: 15,
          title: "Stoicism Archive",
          date: "2026-03-31T01:30:46.000Z",
          url: "https://stoicism.nealfrazier.tech",
          description: "Comprehensive digital archive of Stoic philosophy featuring quotes, biographies, and spiritual exercises.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://stoicism.nealfrazier.tech/og-image.png"
        },
        {
          id: 16,
          title: "AudioCypher",
          date: "2026-03-31T02:39:29.000Z",
          url: "https://audiocypher.757tech.pro",
          description: "High-tech cryptographic tool that uses audio files and volume levels as the entropy key to encrypt, decrypt, and hash files.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://audiocypher.757tech.pro/og-image.png"
        },
        {
          id: 17,
          title: "Cyber Turtle",
          date: "2026-04-01T23:16:49.000Z",
          url: "https://cyberturtle.nealfrazier.tech",
          description: "Neon arcade web game with voice-powered attacks, synthwave vibes, and fast-paced browser action.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://cyberturtle.nealfrazier.tech/og-image.png"
        },
        {
          id: 18,
          title: "Nexus (Agentic API Explorer)",
          date: "2026-04-02T01:47:04.000Z",
          url: "https://nexus.757tech.pro",
          description: "Agentic API explorer + IDE. API testing that works reliably in production.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://nexus.757tech.pro/og-image.png"
        },
        {
          id: 19,
          title: "AuraMap",
          date: "2026-04-02T04:29:18.000Z",
          url: "https://auramap.757tech.pro",
          description: "AI-powered map experience that reveals historical + cultural \u201Cechoes\u201D for any location on Earth.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://auramap.757tech.pro/og-image.png"
        },
        {
          id: 20,
          title: "PackageForge",
          date: "2026-04-04T00:50:45.000Z",
          url: "https://packageforge.757tech.pro",
          description: "AI-powered package generator IDE. Build, iterate, and export production-ready package scaffolds across many languages.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://packageforge.757tech.pro/og-image.png"
        },
        {
          id: 21,
          title: "Universal File Converter",
          date: "2026-04-04T15:42:27.000Z",
          url: "https://universal-file-convertor.streamlit.app",
          description: "Production-ready universal file converter for Linux cloud environments (including Streamlit Cloud).",
          tags: [
            "streamlit"
          ],
          thumbnail: "https://api.microlink.io?url=https%3A%2F%2Funiversal-file-convertor.streamlit.app&screenshot=true&embed=screenshot.url"
        },
        {
          id: 22,
          title: "SignalNest",
          date: "2026-04-04T16:48:15.000Z",
          url: "https://signalnest.nealfrazier.tech",
          description: "Helps founders and creators capture sources, score signal quality, and generate rate-limited AI digests.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://signalnest.nealfrazier.tech/og-image.png"
        },
        {
          id: 23,
          title: "Simple Portfolio Template",
          date: "2026-04-04T17:16:23.000Z",
          url: "https://simple-portfolio.nealfrazier.tech",
          description: "Portfolio template for anyone looking for a simple digital-themed config-based portfolio.",
          tags: [
            "hostinger",
            "openai",
            "netlify"
          ],
          thumbnail: "https://simple-portfolio.nealfrazier.tech/og-image.png"
        },
        {
          id: 24,
          title: "BrainWidth",
          date: "2026-04-04T17:33:29.000Z",
          url: "https://brainwidth.757tech.pro",
          description: "AI-assisted cognitive load planner that helps organize tasks around mental energy and plan sustainable workdays.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://brainwidth.757tech.pro/og-image.png"
        },
        {
          id: 25,
          title: "SloppyJoes",
          date: "2026-04-04T18:21:28.000Z",
          url: "https://sloppyjoes.nealfrazier.tech",
          description: "Chaotic, community-driven parody platform where people share weird AI-generated content, react with daily-limited votes, and browse a fully branded experience.",
          tags: [
            "google-ai-studio",
            "netlify"
          ],
          thumbnail: "https://sloppyjoes.nealfrazier.tech/og-image.png"
        },
        {
          id: 26,
          title: "Procrastinator Pro",
          date: "2026-04-04T20:11:02.000Z",
          url: "https://procrastinatorpro.nealfrazier.tech",
          description: "Satire productivity app with an AI Enabler, existential dread meter, and local-first task deferral tracker.",
          tags: [
            "google-ai-studio",
            "netlify"
          ],
          thumbnail: "https://procrastinatorpro.nealfrazier.tech/og-image.png"
        },
        {
          id: 27,
          title: "Datamosh Studio",
          date: "2026-04-04T20:37:14.000Z",
          url: "https://datamoshstudio.757tech.pro",
          description: "Web-based video editor for real-time datamoshing, glitch effects, and quick WebM exports in your browser.",
          tags: [
            "google-ai-studio",
            "netlify"
          ],
          thumbnail: "https://datamoshstudio.757tech.pro/og-image.png"
        },
        {
          id: 28,
          title: "AuraAI (Front Desk Agent)",
          date: "2026-04-05T03:03:13.000Z",
          url: "https://auraai.757tech.pro",
          description: "AI-powered front desk agent for businesses. Replace receptionist overhead with a 24/7 assistant at lower cost.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://auraai.757tech.pro/og-image.png"
        },
        {
          id: 29,
          title: "KitchenForge",
          date: "2026-04-05T17:01:26.000Z",
          url: "https://kitchenforge.757tech.pro",
          description: "Helps chefs and entrepreneurs launch and scale delivery-first food brands across Hampton Roads, Virginia.",
          tags: [
            "hostinger",
            "openai",
            "netlify"
          ],
          thumbnail: "https://kitchenforge.757tech.pro/og-image.png"
        },
        {
          id: 30,
          title: "HostBuild Directory",
          date: "2026-04-05T20:05:10.000Z",
          url: "https://hostandbuild.757tech.pro",
          description: "Helps you compare website builders, hosting providers, and cloud platforms for projects across the 757 Hampton Roads region.",
          tags: [
            "openai",
            "google-ai-studio",
            "netlify"
          ],
          thumbnail: "https://hostandbuild.757tech.pro/og-image.png"
        },
        {
          id: 31,
          title: "I Got You",
          date: "2026-04-05T20:27:11.000Z",
          url: "https://igotyou.757tech.pro",
          description: "Premium service provider sponsored by Tech Pro, delivering fast digital support, in-person assistance, and curated resources.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://igotyou.757tech.pro/og-image.png"
        },
        {
          id: 32,
          title: "Aetheris AI Workforce Interfaces",
          date: "2026-04-11T04:01:55.000Z",
          url: "https://aetheris-ai-workforce-interfaces.757tech.pro",
          description: "Next-generation GUI interfaces for orchestrating AI agent employees (Dev, Orchestrator, and Customer views).",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://aetheris-ai-workforce-interfaces.757tech.pro/og-image.png"
        },
        {
          id: 33,
          title: "AI Talk AI Go",
          date: "2026-04-11T04:11:40.000Z",
          url: "https://ai-talk-ai-go.nealfrazier.tech",
          description: "Primitive AI assistant for the modern caveman. Talk to Oog, the world\u2019s first LLM (Large Lithic Model).",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://ai-talk-ai-go.nealfrazier.tech/og-image.png"
        },
        {
          id: 34,
          title: "BudScan AI",
          date: "2026-04-11T04:20:04.000Z",
          url: "https://budscan-ai.nealfrazier.tech",
          description: "Advanced cannabis quality scanner using multi-stage AI visual analysis to detect PGR, mold, and quality.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://budscan-ai.nealfrazier.tech/og-image.png"
        },
        {
          id: 35,
          title: "BuildEstimate AI",
          date: "2026-04-11T06:10:36.000Z",
          url: "https://buildestimate-ai.nealfrazier.tech",
          description: "Professional construction estimation tool for residential and commercial projects, powered by AI for deep ROI analysis and cost breakdowns.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://buildestimate-ai.nealfrazier.tech/og-image.png"
        },
        {
          id: 36,
          title: "CertPath",
          date: "2026-04-11T13:54:22.000Z",
          url: "https://certpath-interactive-certification-roadmaps.nealfrazier.tech",
          description: "Canvas-based interactive roadmap for professional certifications across Web, AI, Cyber Security, and more.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://certpath-interactive-certification-roadmaps.nealfrazier.tech/og-image.png"
        },
        {
          id: 37,
          title: "DeepSearch AI",
          date: "2026-04-11T14:06:14.000Z",
          url: "https://deepsearch-ai.nealfrazier.tech",
          description: "Google-inspired search engine that provides deep analysis, visual graphs, and keyword insights using Gemini AI and Google Search grounding.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://deepsearch-ai.nealfrazier.tech/og-image.png"
        },
        {
          id: 38,
          title: "Edge-Forge",
          date: "2026-04-11T14:16:50.000Z",
          url: "https://edge-forge.nealfrazier.tech",
          description: "Build and run private AI workflows directly on your device with WebGPU. Targets teams who need local control, speed, and custom skills.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://edge-forge.nealfrazier.tech/og-image.png"
        },
        {
          id: 39,
          title: "Grip & Grime Game of Skate",
          date: "2026-04-11T14:25:58.000Z",
          url: "https://grip-and-grime-game-of-skate.nealfrazier.tech",
          description: "The ultimate gritty tracker for your Game of S.K.A.T.E. sessions. Track letters, time turns, and capture the clips.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://grip-and-grime-game-of-skate.nealfrazier.tech/og-image.png"
        },
        {
          id: 40,
          title: "Hampton Roads Lawn Care",
          date: "2026-04-11T14:35:41.000Z",
          url: "https://hampton-roads-lawn-care.nealfrazier.tech",
          description: "10-page SEO-optimized lawn care service website for Hampton Roads, Virginia.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://hampton-roads-lawn-care.nealfrazier.tech/og-image.png"
        },
        {
          id: 41,
          title: "Gorilla Funk Skateboards",
          date: "2026-04-11T14:43:52.000Z",
          url: "https://gorilla-funk-skateboards.nealfrazier.tech",
          description: "High-energy platform for skateboard lessons and tips in Virginia Beach, featuring expert coaching and beginner-friendly guides.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://gorilla-funk-skateboards.nealfrazier.tech/og-image.png"
        },
        {
          id: 42,
          title: "JS Mastery Zero to Hero",
          date: "2026-04-11T14:55:50.000Z",
          url: "https://js-mastery-zero-to-hero.nealfrazier.tech",
          description: "Interactive JavaScript learning platform with micro-steps, bento-grid dashboard, and AI-powered waitlist.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://js-mastery-zero-to-hero.nealfrazier.tech/og-image.png"
        },
        {
          id: 43,
          title: "LinguaBot",
          date: "2026-04-11T15:04:32.000Z",
          url: "https://linguabot.nealfrazier.tech",
          description: "Real-time conversational AI language learning partner.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://linguabot.nealfrazier.tech/og-image.png"
        },
        {
          id: 44,
          title: "Nexus 3D Editor",
          date: "2026-04-11T15:12:59.000Z",
          url: "https://nexus-3d-editor.nealfrazier.tech",
          description: "Lightweight, powerful 3D model loader and editor inspired by Spline and Blender.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://nexus-3d-editor.nealfrazier.tech/og-image.png"
        },
        {
          id: 45,
          title: "OmniPost",
          date: "2026-04-11T21:22:00.000Z",
          url: "https://omnipost-social-media-manager.nealfrazier.tech",
          description: "Create, optimize, and manage posts for all your social media platforms with AI assistance and SEO tools.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://omnipost-social-media-manager.nealfrazier.tech/og-image.png"
        },
        {
          id: 46,
          title: "Local Business Lead Scanner",
          date: "2026-04-11T21:32:25.000Z",
          url: "https://local-business-lead-scanner.nealfrazier.tech",
          description: "Scan OpenStreetMap business data to find local leads with no website listed.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://local-business-lead-scanner.nealfrazier.tech/og-image.png"
        },
        {
          id: 47,
          title: "Gyro Spin Bottle",
          date: "2026-04-11T22:32:42.000Z",
          url: "https://gyro-spin-bottle.nealfrazier.tech",
          description: "Fun simple spin-the-bottle game that uses your device\u2019s gyroscope to spin a 2D glass bottle.",
          tags: [
            "google-ai-studio",
            "netlify"
          ],
          thumbnail: "https://gyro-spin-bottle.nealfrazier.tech/og-image.png"
        },
        {
          id: 48,
          title: "Origin Cacao",
          date: "2026-04-11T22:51:36.000Z",
          url: "https://origin-cacao-the-oceanfront-fix.nealfrazier.tech",
          description: "Cacao Cafe concept \u2013 \u201COpening soon at the Virginia Beach oceanfront. Join the ORIGIN Cacao waitlist for first access and launch updates.\u201D",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://origin-cacao-the-oceanfront-fix.nealfrazier.tech/og-image.png"
        },
        {
          id: 49,
          title: "PromptMaster",
          date: "2026-04-11T23:11:48.000Z",
          url: "https://promptmaster.757tech.pro",
          description: "Comprehensive, free platform to master prompt engineering, LLM orchestration, and AI agent development from local setups to production tools.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://promptmaster.757tech.pro/og-image.png"
        },
        {
          id: 50,
          title: "Feral Tide Strategy",
          date: "2026-04-11T23:50:10.000Z",
          url: "https://feraltidestrategy.757tech.pro",
          description: "Virginia Beach consulting site focused on offer design, AI-assisted operations, and disciplined growth systems.",
          tags: [
            "openai",
            "netlify"
          ],
          thumbnail: "https://feraltidestrategy.757tech.pro/og-image.png"
        },
        {
          id: 51,
          title: "Sand & Stems Virginia Beach Flower Delivery",
          date: "2026-04-12T15:29:57.000Z",
          url: "https://sand-and-stems-virginia-beach-flower-delivery.nealfrazier.tech",
          description: "Premium floral delivery service directly to your spot on the Virginia Beach oceanfront. Beautiful blooms, beach vibes, and unforgettable moments.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://sand-and-stems-virginia-beach-flower-delivery.nealfrazier.tech/og-image.png"
        },
        {
          id: 52,
          title: "Skate Archive Heaven",
          date: "2026-04-12T17:05:15.000Z",
          url: "https://skate-archive-heaven.nealfrazier.tech",
          description: "Comprehensive archive of historical skaters, iconic brands, and legendary skate videos.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://skate-archive-heaven.nealfrazier.tech/og-image.png"
        },
        {
          id: 53,
          title: "The Greene Strategist",
          date: "2026-04-12T17:06:55.000Z",
          url: "https://the-greene-strategist.nealfrazier.tech",
          description: "Explore Robert Greene biography, key works, strategic philosophy, and curated official resources in one focused reference.",
          tags: [
            "ollama",
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://the-greene-strategist.nealfrazier.tech/og-image.png"
        },
        {
          id: 54,
          title: "Veganify AI",
          date: "2026-04-12T17:08:26.000Z",
          url: "https://veganify-ai.nealfrazier.tech",
          description: "Transform any non-vegan dish into a delicious plant-based masterpiece using AI-powered image recognition and recipe generation.",
          tags: [
            "google-ai-studio",
            "netlify"
          ],
          thumbnail: "https://veganify-ai.nealfrazier.tech/og-image.png"
        },
        {
          id: 55,
          title: "Stripe Mastery Hub",
          date: "2026-04-12T17:45:56.000Z",
          url: "https://stripe-mastery-hub.nealfrazier.tech",
          description: "The ultimate developer resource for Stripe integrations. AI-powered flow generation, 50+ framework support, real-world code snippets, and comprehensive guides for webhooks, subscriptions, and no-code tools.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://stripe-mastery-hub.nealfrazier.tech/og-image.png"
        },
        {
          id: 56,
          title: "V-EDGE Vegan Pizza",
          date: "2026-04-12T17:54:30.000Z",
          url: "https://v-edge-vegan-pizza.nealfrazier.tech",
          description: "V-EDGE Vegan Pizza is coming soon to Virginia Beach. Preview signature pies, see rollout zones, and join the waitlist for first-access launch drops.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://v-edge-vegan-pizza.nealfrazier.tech/og-image.png"
        },
        {
          id: 57,
          title: "SonicVision AI",
          date: "2026-04-12T18:57:34.000Z",
          url: "https://sonicvision-ai.nealfrazier.tech",
          description: "An advanced 3D audio visualizer with AI-powered captions and video export capabilities. Turn any sound into a stunning visual experience.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://sonicvision-ai.nealfrazier.tech/og-image.png"
        },
        {
          id: 58,
          title: "Unthink AI",
          date: "2026-04-12T18:59:38.000Z",
          url: "https://unthink-ai.757tech.pro",
          description: "The world\u2019s first decision-making AI for trivial dilemmas. Built by Tech Pro and Google-inspired \u2014 because sometimes you just need an AI to overthink the small stuff for you.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://unthink-ai.757tech.pro/og-image.png"
        },
        {
          id: 59,
          title: "SignalBridge AI",
          date: "2026-04-12T19:02:04.000Z",
          url: "https://signalbridge-ai.757tech.pro",
          description: "Connect your private Signal messages to local AI agents, custom backends, and complex orchestrators. Secure, end-to-end encrypted, and entirely under your control.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://signalbridge-ai.757tech.pro/og-image.png"
        },
        {
          id: 60,
          title: "VoltVault",
          date: "2026-04-12T19:15:03.000Z",
          url: "https://voltvault-electricians-digital-panel-and-tools.nealfrazier.tech",
          description: "A professional tool for electricians to manage digital breaker panels, map circuits, and perform electrical calculations on the fly.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://voltvault-electricians-digital-panel-and-tools.nealfrazier.tech/og-image.png"
        },
        {
          id: 61,
          title: "VisionLink (Face & Hand Control)",
          date: "2026-04-12T19:16:30.000Z",
          url: "https://vision-link-face-and-hand-control.nealfrazier.tech",
          description: "An interactive vision-based application for facial vector mapping and hand tracking with gesture-controlled zones.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://vision-link-face-and-hand-control.nealfrazier.tech/og-image.png"
        },
        {
          id: 62,
          title: "Boom Pow",
          date: "2026-04-14T06:14:39.000Z",
          url: "https://boompow.online",
          description: "Boom Pow is a vegan fast food ghost kitchen serving crispy sandwiches, wraps, fries, and shakes at the Virginia Beach Oceanfront.",
          tags: [
            "openclaw",
            "ollama",
            "openai",
            "netlify"
          ],
          thumbnail: "https://boompow.online/og-image.png"
        },
        {
          id: 63,
          title: "Adytum Alchemist Guide",
          date: "2026-04-19T17:03:52.000Z",
          url: "https://adytum-alchemist-guide.nealfrazier.tech/",
          description: "Unlock the secrets of BOTA Tarot through AI. Adytum Alchemist Guide blends occult symbolism with modern AI chemistry to map Key 0 to Key 21.",
          tags: [
            "google-ai-studio",
            "ollama",
            "openai",
            "netlify"
          ],
          thumbnail: "https://adytum-alchemist-guide.nealfrazier.tech/og-image.png"
        },
        {
          id: 64,
          title: "AI AgentUI",
          date: "2026-04-19T17:05:13.000Z",
          url: "https://ai-agentui.757tech.pro/",
          description: "Stop building AI chat interfaces from scratch. Get 50+ plug-and-play React/HTML components to ship your AI agent faster. Copy, paste, and deploy.",
          tags: [
            "google-ai-studio",
            "ollama",
            "openai",
            "netlify"
          ],
          thumbnail: "https://ai-agentui.757tech.pro/og-image.png"
        },
        {
          id: 65,
          title: "Avatar Studio",
          date: "2026-04-19T17:06:36.000Z",
          url: "https://avatar-studio.757tech.pro/",
          description: "Stop hunting for profile pics. Avatar Studio lets you generate custom, high-quality avatars instantly using the DiceBear API. Perfect for devs and creators.",
          tags: [
            "google-ai-studio",
            "ollama",
            "openai",
            "netlify"
          ],
          thumbnail: "https://avatar-studio.757tech.pro/og-image.png"
        },
        {
          id: 66,
          title: "Badge3D",
          date: "2026-04-19T17:08:46.000Z",
          url: "https://t.co/1ylaesScEz",
          description: "Stop struggling with complex 3D software. Turn any 2D logo into a professional 3D coin or badge instantly with Badge3D. Perfect for branding, game assets, and social profiles.",
          tags: [
            "google-ai-studio",
            "ollama",
            "openai",
            "netlify"
          ],
          thumbnail: "https://api.microlink.io?url=https%3A%2F%2Ft.co%2F1ylaesScEz&screenshot=true&embed=screenshot.url"
        },
        {
          id: 67,
          title: "Crypto Tracker Agent",
          date: "2026-04-19T17:10:13.000Z",
          url: "https://t.co/RmumEY1lTq",
          description: "Stop guessing market direction. Get Relational Market Intelligence with Crypto Tracker Agent. Track divergence pairs, rolling correlations, and live price structures in one place.",
          tags: [
            "google-ai-studio",
            "ollama",
            "openai",
            "netlify"
          ],
          thumbnail: "https://api.microlink.io?url=https%3A%2F%2Ft.co%2FRmumEY1lTq&screenshot=true&embed=screenshot.url"
        },
        {
          id: 68,
          title: "Echo Shrine",
          date: "2026-04-19T17:11:25.000Z",
          url: "https://echo-shrine.nealfrazier.tech/",
          description: "Stop losing your best ideas to digital noise. Echo Shrine is a cinematic memory palace for founders and artists blending dark UI with high-recall storytelling.",
          tags: [
            "google-ai-studio",
            "ollama",
            "openai",
            "netlify"
          ],
          thumbnail: "https://echo-shrine.nealfrazier.tech/og-image.png"
        },
        {
          id: 69,
          title: "EnvGuard Pro",
          date: "2026-04-19T17:13:14.000Z",
          url: "https://envguard-pro.757tech.pro/",
          description: "Stop leaking secrets in your CI/CD. EnvGuard Pro brings enterprise-grade environment variable security, automated rotation, and AI honeypots to your stack.",
          tags: [
            "google-ai-studio",
            "ollama",
            "openai",
            "netlify"
          ],
          thumbnail: "https://envguard-pro.757tech.pro/og-image.png"
        },
        {
          id: 70,
          title: "Hacker Portfolio V2",
          date: "2026-04-19T17:19:10.000Z",
          url: "https://t.co/MS1pVJxJyb",
          description: "Launch: Hacker Portfolio V2. A Neo-Cyberpunk terminal with matrix effects & command simulation. Solve the boring portfolio problem with an immersive dev experience.",
          tags: [
            "google-ai-studio",
            "ollama",
            "openai",
            "netlify"
          ],
          thumbnail: "https://api.microlink.io?url=https%3A%2F%2Ft.co%2FMS1pVJxJyb&screenshot=true&embed=screenshot.url"
        },
        {
          id: 71,
          title: "Neon Pulse",
          date: "2026-04-19T17:21:16.000Z",
          url: "https://t.co/kN0mFtVFWY",
          description: "Enter the data stream. Neon Pulse is live: a high-octane arcade experience. Dodge glitches, collect sync nodes, and master the 2026 grid. Mobile-first and fast.",
          tags: [
            "ollama",
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://api.microlink.io?url=https%3A%2F%2Ft.co%2FkN0mFtVFWY&screenshot=true&embed=screenshot.url"
        },
        {
          id: 72,
          title: "nona",
          date: "2026-04-19T17:22:11.000Z",
          url: "https://nona.757tech.pro/",
          description: "Stop choosing between speed and quality. nona delivers high-edge tech services with a bold, cartoon aesthetic. Fast production, premium results.",
          tags: [
            "ollama",
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://nona.757tech.pro/og-image.png"
        },
        {
          id: 73,
          title: "Off-Grid AI Guide",
          date: "2026-04-19T17:23:57.000Z",
          url: "https://t.co/myzpy5mqnw",
          description: "Master the wilderness with the power of local AI. From solar setups to survival tactics, get the ultimate off-grid guide by Neal Frazier. Stop relying on the cloud when you're off the map.",
          tags: [
            "ollama",
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://api.microlink.io?url=https%3A%2F%2Ft.co%2Fmyzpy5mqnw&screenshot=true&embed=screenshot.url"
        },
        {
          id: 74,
          title: "ONE SHOT",
          date: "2026-04-19T17:31:20.000Z",
          url: "https://t.co/fR9xIkV7gE",
          description: "Stop guessing. Start executing. ONE SHOT is the definitive directory for high-precision AI prompts and Codex. Tactical minimalist design for maximum output.",
          tags: [
            "ollama",
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://api.microlink.io?url=https%3A%2F%2Ft.co%2FfR9xIkV7gE&screenshot=true&embed=screenshot.url"
        },
        {
          id: 75,
          title: "Paws & Paths Virginia Beach",
          date: "2026-04-19T17:32:21.000Z",
          url: "https://paws-paths.nealfrazier.tech/",
          description: "Stop stressing over dog walks and messy yards. Paws & Paths Virginia Beach is live! Reliable dog walking and pet waste removal for busy pet owners.",
          tags: [
            "ollama",
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://paws-paths.nealfrazier.tech/og-image.png"
        },
        {
          id: 76,
          title: "WWHFD (What Would Henry Ford Do)",
          date: "2026-04-19T17:33:21.000Z",
          url: "https://wwhfd.nealfrazier.tech/",
          description: "Stop guessing about automation. WWHFD explores the evolution of efficiency from Pyramids to AI. Solve the mystery of scalable innovation.",
          tags: [
            "ollama",
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://wwhfd.nealfrazier.tech/og-image.png"
        },
        {
          id: 77,
          title: "Zen Breathing Companion",
          date: "2026-04-19T17:34:15.000Z",
          url: "https://t.co/PkZfReMmiP",
          description: "Stop the digital noise. Zen Breathing Companion is a minimalist, atmospheric timer designed to reduce stress and improve focus through guided breathing. Perfect for quick resets. Try\u2026",
          tags: [
            "ollama",
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://api.microlink.io?url=https%3A%2F%2Ft.co%2FPkZfReMmiP&screenshot=true&embed=screenshot.url"
        },
        {
          id: 78,
          title: "100WebsitesIn30Days",
          date: "2026-04-19T22:50:15.000Z",
          url: "https://100websitesin30days.nealfrazier.tech/",
          description: "This website showcases the challenge #100WebsitesIn30Days and my progress along its journey. Includes all drops, timeline articles, resources, and a passage way to join the challenge yourself!!",
          tags: [
            "netlify",
            "google-ai-studio",
            "openai",
            "ollama"
          ],
          thumbnail: "https://100websitesin30days.nealfrazier.tech/og-image.png"
        },
        {
          id: 79,
          title: "Neal Frazier Tech (Bliki)",
          date: "2026-04-20T01:10:23.000Z",
          url: "https://www.nealfrazier.tech",
          description: "I have revamped Neal Frazier Tech. This is now a Bliki website which I would like to say thank you @ChaiWithJai for the major influence and guidance on making this shift. This is an ongoing project and is another #buildinpublic project. The old sites url is https://t.co/dsKWMKsMec",
          tags: [
            "netlify",
            "google-ai-studio",
            "openai",
            "ollama"
          ],
          thumbnail: "https://www.nealfrazier.tech/og-image.png"
        },
        {
          id: 80,
          title: "Python 30",
          date: "2026-04-21T02:22:35.000Z",
          url: "https://python-30.nealfrazier.tech/",
          description: "A free interactive guide to mastering Python in 30 days with a personalized AI tutor.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify",
            "ollama"
          ],
          thumbnail: "https://python-30.nealfrazier.tech/og-image.png"
        },
        {
          id: 81,
          title: "Python Math",
          date: "2026-04-21T02:39:14.000Z",
          url: "https://python-math.nealfrazier.tech/",
          description: "Learn math through Python with daily interactive lessons and challenges.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify",
            "ollama"
          ],
          thumbnail: "https://python-math.nealfrazier.tech/og-image.png"
        },
        {
          id: 82,
          title: "AI Mastery",
          date: "2026-04-21T02:44:49.000Z",
          url: "https://ai-mastery.nealfrazier.tech/",
          description: "A comprehensive 30-day curriculum to master AI tools, prompt engineering, agents, and security. Start your journey to becoming an AI expert today.",
          tags: [
            "google-ai-studio",
            "openai",
            "ollama",
            "netlify"
          ],
          thumbnail: "https://ai-mastery.nealfrazier.tech/og-image.png"
        },
        {
          id: 83,
          title: "AI University",
          date: "2026-04-21T02:50:00.000Z",
          url: "https://ai-university.nealfrazier.tech/",
          description: "Von Neumann University offers higher learning for higher intelligence. A prestigious university for AI employees, specializing in NLP, Tool Use, and Alignment.",
          tags: [
            "google-ai-studio",
            "openai",
            "ollama",
            "netlify"
          ],
          thumbnail: "https://ai-university.nealfrazier.tech/og-image.png"
        },
        {
          id: 84,
          title: "C in 30",
          date: "2026-04-21T02:54:44.000Z",
          url: "https://c-in-30.nealfrazier.tech/",
          description: "A practical 30-day C programming course with daily exercises, guided projects, and fundamentals for modern systems programming.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify",
            "ollama"
          ],
          thumbnail: "https://c-in-30.nealfrazier.tech/og-image.png"
        },
        {
          id: 85,
          title: "Forge Fracture",
          date: "2026-04-21T03:04:12.000Z",
          url: "https://forge-fracture.nealfrazier.tech/",
          description: "A high-fidelity social hub for radical digital creatives. Architect monoliths, induce creative entropy, and evolve the neural mesh.",
          tags: [
            "google-ai-studio",
            "openai",
            "ollama",
            "netlify"
          ],
          thumbnail: "https://forge-fracture.nealfrazier.tech/og-image.png"
        },
        {
          id: 86,
          title: "IdleKey",
          date: "2026-04-21T03:32:07.000Z",
          url: "https://idlekey.nealfrazier.tech/",
          description: "Tired of the AI hype? Monetize your apathy. Sell your unused AI free-tier API quotas and get paid for doing absolutely nothing.",
          tags: [
            "google-ai-studio",
            "openai",
            "ollama",
            "netlify"
          ],
          thumbnail: "https://idlekey.nealfrazier.tech/og-image.png"
        },
        {
          id: 87,
          title: "30 Days Linux Fundamentals",
          date: "2026-04-22T01:13:45.000Z",
          url: "https://30-days-linux-fundamentals.nealfrazier.tech/",
          description: "This was a special one. Converted one of my first repos I made a couple years ago into an immersive Astro js framework. Start Learning Linux today!!",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://30-days-linux-fundamentals.nealfrazier.tech/og-image.png"
        },
        {
          id: 88,
          title: "Nova OS Analytics",
          date: "2026-04-22T03:04:33.000Z",
          url: "https://nova-os-analytics.nealfrazier.tech/",
          description: "Explore a public-ready analytics product shell with reusable templates, AI-powered dashboard generation, and deployment-safe UX patterns.",
          tags: [
            "google-ai-studio",
            "openai",
            "ollama",
            "netlify"
          ],
          thumbnail: "https://nova-os-analytics.nealfrazier.tech/og-image.png"
        },
        {
          id: 89,
          title: "BlockFans",
          date: "2026-04-22T03:17:55.000Z",
          url: "https://blockfans.nealfrazier.tech/",
          description: "Join the BlockFans waitlist for early access to a Web3 creator network with direct fan support, wallet-based identity, and on-chain subscriptions.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://blockfans.nealfrazier.tech/og-image.png"
        },
        {
          id: 90,
          title: "PowerShell 30",
          date: "2026-04-22T03:23:28.000Z",
          url: "https://learn-powershell-in-30-days.nealfrazier.tech/",
          description: "A practical, day-by-day learning path to build real PowerShell skills in 30 days.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://learn-powershell-in-30-days.nealfrazier.tech/og-image.png"
        },
        {
          id: 91,
          title: "CISA GRC Study Portal",
          date: "2026-04-22T03:25:59.000Z",
          url: "https://cisa-grc-study-portal.nealfrazier.tech/",
          description: "An interactive study portal for CISA and GRC preparation with practice content and exam-focused guidance.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://cisa-grc-study-portal.nealfrazier.tech/og-image.png"
        },
        {
          id: 92,
          title: "Yell Space",
          date: "2026-04-22T03:37:07.000Z",
          url: "https://yell-space.nealfrazier.tech/",
          description: "A voice-based stress release app that helps people vent safely and reflect with AI-powered analysis.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://yell-space.nealfrazier.tech/og-image.png"
        },
        {
          id: 93,
          title: "Prepped Pigeon",
          date: "2026-04-23T01:17:44.000Z",
          url: "https://prepped-pigeon.nealfrazier.tech/",
          description: "Find and reserve parking spots, valet services, and venue reservations in Virginia Beach.",
          tags: [
            "google-ai-studio",
            "netlify",
            "openai"
          ],
          thumbnail: "https://prepped-pigeon.nealfrazier.tech/og-image.png"
        },
        {
          id: 94,
          title: "NFC Link Hub",
          date: "2026-04-23T01:30:23.000Z",
          url: "https://nfc-link-hub.nealfrazier.tech/",
          description: "A social profile link aggregator with integrated NFC tools for physical sharing and tag writing.",
          tags: [
            "google-ai-studio",
            "openai",
            "ollama",
            "netlify",
            "supabase"
          ],
          thumbnail: "https://nfc-link-hub.nealfrazier.tech/og-image.png"
        },
        {
          id: 95,
          title: "JusticeWatch",
          date: "2026-04-23T01:39:57.000Z",
          url: "https://justicewatch.nealfrazier.tech/",
          description: "Join the JusticeWatch waitlist to unlock a 2026 incident briefing map with source-linked, area-specific case details.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://justicewatch.nealfrazier.tech/og-image.png"
        },
        {
          id: 96,
          title: "Tidepoint Strategic",
          date: "2026-04-23T01:48:45.000Z",
          url: "https://tidepoint.757tech.pro/",
          description: "Tidepoint Strategic is a Hampton Roads think tank helping teams ship faster through AI-augmented strategy, tactical foresight, and execution support.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://tidepoint.757tech.pro/og-image.png"
        },
        {
          id: 97,
          title: "Pied Piper",
          date: "2026-04-23T01:53:20.000Z",
          url: "https://piedpiper.nealfrazier.tech/",
          description: "Pied Piper: The next generation of decentralized lossless compression. Built on the revolutionary Middle-Out engine by Richard Hendricks.",
          tags: [
            "google-ai-studio",
            "netlify"
          ],
          thumbnail: "https://piedpiper.nealfrazier.tech/og-image.png"
        },
        {
          id: 98,
          title: "Bullseye",
          date: "2026-04-23T02:27:22.000Z",
          url: "https://bullseye.nealfrazier.tech/",
          description: "The lead generation platform for recruiters tired of wasting time on LinkedIn spam. We guarantee you message the right people.",
          tags: [
            "google-ai-studio",
            "netlify"
          ],
          thumbnail: "https://bullseye.nealfrazier.tech/og-image.png"
        },
        {
          id: 99,
          title: "MigrateX",
          date: "2026-04-23T02:44:25.000Z",
          url: "https://migratex.757tech.pro/",
          description: "X is phasing out Communities, but your people aren't going anywhere. Use MigrateX to keep your network together.",
          tags: [
            "google-ai-studio",
            "netlify"
          ],
          thumbnail: "https://migratex.757tech.pro/og-image.png"
        },
        {
          id: 100,
          title: "Riff Raff",
          date: "2026-04-23T03:33:10.000Z",
          url: "https://riffraff.nealfrazier.tech/",
          description: "Master the art of Riff Raff metaphors. Explore the Neon Icon dictionary of 1,000+ absurd luxury references or generate your own 'Rap Game' personas.",
          tags: [
            "google-ai-studio",
            "openai",
            "netlify"
          ],
          thumbnail: "https://riffraff.nealfrazier.tech/og-image.png"
        }
      ],
      socialPosts: [
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2047156800038846592",
          content: "#100 Riff Raff \u2014 Master the art of Riff Raff metaphors. Explore the Neon Icon dictionary of 1,000+ absurd luxury references or generate your own 'Rap Game' personas.",
          date: "2026-04-23T03:33:10.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2047144534627271052",
          content: "#99 MigrateX \u2014 X is phasing out Communities, but your people aren't going anywhere. Use MigrateX to keep your network together.",
          date: "2026-04-23T02:44:25.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2047140241396429283",
          content: "#98 Bullseye \u2014 The lead generation platform for recruiters tired of wasting time on LinkedIn spam. We guarantee you message the right people.",
          date: "2026-04-23T02:27:22.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2047131679081312355",
          content: "#97 Pied Piper \u2014 Pied Piper: The next generation of decentralized lossless compression. Built on the revolutionary Middle-Out engine by Richard Hendricks.",
          date: "2026-04-23T01:53:20.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2047130522875273549",
          content: "#96 Tidepoint Strategic \u2014 Tidepoint Strategic is a Hampton Roads think tank helping teams ship faster through AI-augmented strategy, tactical foresight, and execution support.",
          date: "2026-04-23T01:48:45.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2047128307817153011",
          content: "#95 JusticeWatch \u2014 Join the JusticeWatch waitlist to unlock a 2026 incident briefing map with source-linked, area-specific case details.",
          date: "2026-04-23T01:39:57.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2047125903109419208",
          content: "#94 NFC Link Hub \u2014 A social profile link aggregator with integrated NFC tools for physical sharing and tag writing.",
          date: "2026-04-23T01:30:23.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2047122717791441097",
          content: "#93 Prepped Pigeon \u2014 Find and reserve parking spots, valet services, and venue reservations in Virginia Beach.",
          date: "2026-04-23T01:17:44.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2046795406441357331",
          content: "#92 Yell Space \u2014 A voice-based stress release app that helps people vent safely and reflect with AI-powered analysis.",
          date: "2026-04-22T03:37:07.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2046792605862670445",
          content: "#91 CISA GRC Study Portal \u2014 An interactive study portal for CISA and GRC preparation with practice content and exam-focused guidance.",
          date: "2026-04-22T03:25:59.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2046791972036260102",
          content: "#90 PowerShell 30 \u2014 A practical, day-by-day learning path to build real PowerShell skills in 30 days.",
          date: "2026-04-22T03:23:28.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2046790575312052419",
          content: "#89 BlockFans \u2014 Join the BlockFans waitlist for early access to a Web3 creator network with direct fan support, wallet-based identity, and on-chain subscriptions.",
          date: "2026-04-22T03:17:55.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2046787213573107795",
          content: "#88 Nova OS Analytics \u2014 Explore a public-ready analytics product shell with reusable templates, AI-powered dashboard generation, and deployment-safe UX patterns.",
          date: "2026-04-22T03:04:33.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2046759328741282164",
          content: "#87 30 Days Linux Fundamentals \u2014 This was a special one. Converted one of my first repos I made a couple years ago into an immersive Astro js framework. Start Learning Linux today!!",
          date: "2026-04-22T01:13:45.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2046431763619049826",
          content: "#86 IdleKey \u2014 Tired of the AI hype? Monetize your apathy. Sell your unused AI free-tier API quotas and get paid for doing absolutely nothing.",
          date: "2026-04-21T03:32:07.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2046424735932637487",
          content: "#85 Forge Fracture \u2014 A high-fidelity social hub for radical digital creatives. Architect monoliths, induce creative entropy, and evolve the neural mesh.",
          date: "2026-04-21T03:04:12.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2046422354738201078",
          content: "#84 C in 30 \u2014 A practical 30-day C programming course with daily exercises, guided projects, and fundamentals for modern systems programming.",
          date: "2026-04-21T02:54:44.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2046421162557620378",
          content: "#83 AI University \u2014 Von Neumann University offers higher learning for higher intelligence. A prestigious university for AI employees, specializing in NLP, Tool Use, and Alignment.",
          date: "2026-04-21T02:50:00.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2046419857046925535",
          content: "#82 AI Mastery \u2014 A comprehensive 30-day curriculum to master AI tools, prompt engineering, agents, and security. Start your journey to becoming an AI expert today.",
          date: "2026-04-21T02:44:49.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2046418455105077535",
          content: "#81 Python Math \u2014 Learn math through Python with daily interactive lessons and challenges.",
          date: "2026-04-21T02:39:14.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2046414264794038615",
          content: "#80 Python 30 \u2014 A free interactive guide to mastering Python in 30 days with a personalized AI tutor.",
          date: "2026-04-21T02:22:35.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2046033703986413986",
          content: "#79 Neal Frazier Tech (Bliki) \u2014 I have revamped Neal Frazier Tech. This is now a Bliki website which I would like to say thank you @ChaiWithJai for the major influence and guidance on making this shift. This is an ongoing project and is another #buildinpublic project. The old sites url is https://t.co/dsKWMKsMec",
          date: "2026-04-20T01:10:23.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2045998440115577124",
          content: "#78 100WebsitesIn30Days \u2014 This website showcases the challenge #100WebsitesIn30Days and my progress along its journey. Includes all drops, timeline articles, resources, and a passage way to join the challenge yourself!!",
          date: "2026-04-19T22:50:15.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2045918917533515822",
          content: "#77 Zen Breathing Companion \u2014 Stop the digital noise. Zen Breathing Companion is a minimalist, atmospheric timer designed to reduce stress and improve focus through guided breathing. Perfect for quick resets. Try\u2026",
          date: "2026-04-19T17:34:15.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2045918687748632965",
          content: "#76 WWHFD (What Would Henry Ford Do) \u2014 Stop guessing about automation. WWHFD explores the evolution of efficiency from Pyramids to AI. Solve the mystery of scalable innovation.",
          date: "2026-04-19T17:33:21.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2045918437562777806",
          content: "#75 Paws & Paths Virginia Beach \u2014 Stop stressing over dog walks and messy yards. Paws & Paths Virginia Beach is live! Reliable dog walking and pet waste removal for busy pet owners.",
          date: "2026-04-19T17:32:21.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2045918180904747113",
          content: "#74 ONE SHOT \u2014 Stop guessing. Start executing. ONE SHOT is the definitive directory for high-precision AI prompts and Codex. Tactical minimalist design for maximum output.",
          date: "2026-04-19T17:31:20.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2045916323968864567",
          content: "#73 Off-Grid AI Guide \u2014 Master the wilderness with the power of local AI. From solar setups to survival tactics, get the ultimate off-grid guide by Neal Frazier. Stop relying on the cloud when you're off the map.",
          date: "2026-04-19T17:23:57.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2045915877065830620",
          content: "#72 nona \u2014 Stop choosing between speed and quality. nona delivers high-edge tech services with a bold, cartoon aesthetic. Fast production, premium results.",
          date: "2026-04-19T17:22:11.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2045915646903427338",
          content: "#71 Neon Pulse \u2014 Enter the data stream. Neon Pulse is live: a high-octane arcade experience. Dodge glitches, collect sync nodes, and master the 2026 grid. Mobile-first and fast.",
          date: "2026-04-19T17:21:16.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2045915120778576055",
          content: "#70 Hacker Portfolio V2 \u2014 Launch: Hacker Portfolio V2. A Neo-Cyberpunk terminal with matrix effects & command simulation. Solve the boring portfolio problem with an immersive dev experience.",
          date: "2026-04-19T17:19:10.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2045913626603585829",
          content: "#69 EnvGuard Pro \u2014 Stop leaking secrets in your CI/CD. EnvGuard Pro brings enterprise-grade environment variable security, automated rotation, and AI honeypots to your stack.",
          date: "2026-04-19T17:13:14.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2045913169403523140",
          content: "#68 Echo Shrine \u2014 Stop losing your best ideas to digital noise. Echo Shrine is a cinematic memory palace for founders and artists blending dark UI with high-recall storytelling.",
          date: "2026-04-19T17:11:25.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2045912866046263702",
          content: "#67 Crypto Tracker Agent \u2014 Stop guessing market direction. Get Relational Market Intelligence with Crypto Tracker Agent. Track divergence pairs, rolling correlations, and live price structures in one place.",
          date: "2026-04-19T17:10:13.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2045912503448682517",
          content: "#66 Badge3D \u2014 Stop struggling with complex 3D software. Turn any 2D logo into a professional 3D coin or badge instantly with Badge3D. Perfect for branding, game assets, and social profiles.",
          date: "2026-04-19T17:08:46.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2045911955597332685",
          content: "#65 Avatar Studio \u2014 Stop hunting for profile pics. Avatar Studio lets you generate custom, high-quality avatars instantly using the DiceBear API. Perfect for devs and creators.",
          date: "2026-04-19T17:06:36.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2045911608212304024",
          content: "#64 AI AgentUI \u2014 Stop building AI chat interfaces from scratch. Get 50+ plug-and-play React/HTML components to ship your AI agent faster. Copy, paste, and deploy.",
          date: "2026-04-19T17:05:13.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2045911269954240806",
          content: "#63 Adytum Alchemist Guide \u2014 Unlock the secrets of BOTA Tarot through AI. Adytum Alchemist Guide blends occult symbolism with modern AI chemistry to map Key 0 to Key 21.",
          date: "2026-04-19T17:03:52.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2043935950451990938",
          content: "#62 Boom Pow \u2014 Boom Pow is a vegan fast food ghost kitchen serving crispy sandwiches, wraps, fries, and shakes at the Virginia Beach Oceanfront.",
          date: "2026-04-14T06:14:39.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2043407934621704217",
          content: "#61 VisionLink (Face & Hand Control) \u2014 An interactive vision-based application for facial vector mapping and hand tracking with gesture-controlled zones.",
          date: "2026-04-12T19:16:30.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2043407569381724251",
          content: "#60 VoltVault \u2014 A professional tool for electricians to manage digital breaker panels, map circuits, and perform electrical calculations on the fly.",
          date: "2026-04-12T19:15:03.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2043404300299194717",
          content: "#59 SignalBridge AI \u2014 Connect your private Signal messages to local AI agents, custom backends, and complex orchestrators. Secure, end-to-end encrypted, and entirely under your control.",
          date: "2026-04-12T19:02:04.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2043403687284932735",
          content: "#58 Unthink AI \u2014 The world\u2019s first decision-making AI for trivial dilemmas. Built by Tech Pro and Google-inspired \u2014 because sometimes you just need an AI to overthink the small stuff for you.",
          date: "2026-04-12T18:59:38.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2043403168168440085",
          content: "#57 SonicVision AI \u2014 An advanced 3D audio visualizer with AI-powered captions and video export capabilities. Turn any sound into a stunning visual experience.",
          date: "2026-04-12T18:57:34.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2043387295529566526",
          content: "#56 V-EDGE Vegan Pizza \u2014 V-EDGE Vegan Pizza is coming soon to Virginia Beach. Preview signature pies, see rollout zones, and join the waitlist for first-access launch drops.",
          date: "2026-04-12T17:54:30.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2043385141150757063",
          content: "#55 Stripe Mastery Hub \u2014 The ultimate developer resource for Stripe integrations. AI-powered flow generation, 50+ framework support, real-world code snippets, and comprehensive guides for webhooks, subscriptions, and no-code tools.",
          date: "2026-04-12T17:45:56.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2043375704817930415",
          content: "#54 Veganify AI \u2014 Transform any non-vegan dish into a delicious plant-based masterpiece using AI-powered image recognition and recipe generation.",
          date: "2026-04-12T17:08:26.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2043375321475428642",
          content: "#53 The Greene Strategist \u2014 Explore Robert Greene biography, key works, strategic philosophy, and curated official resources in one focused reference.",
          date: "2026-04-12T17:06:55.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2043374901713678768",
          content: "#52 Skate Archive Heaven \u2014 Comprehensive archive of historical skaters, iconic brands, and legendary skate videos.",
          date: "2026-04-12T17:05:15.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2043350921271251057",
          content: "#51 Sand & Stems Virginia Beach Flower Delivery \u2014 Premium floral delivery service directly to your spot on the Virginia Beach oceanfront. Beautiful blooms, beach vibes, and unforgettable moments.",
          date: "2026-04-12T15:29:57.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2043114417173233782",
          content: "#50 Feral Tide Strategy \u2014 Virginia Beach consulting site focused on offer design, AI-assisted operations, and disciplined growth systems.",
          date: "2026-04-11T23:50:10.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2043104760086049261",
          content: "#49 PromptMaster \u2014 Comprehensive, free platform to master prompt engineering, LLM orchestration, and AI agent development from local setups to production tools.",
          date: "2026-04-11T23:11:48.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2043099675973095713",
          content: "#48 Origin Cacao \u2014 Cacao Cafe concept \u2013 \u201COpening soon at the Virginia Beach oceanfront. Join the ORIGIN Cacao waitlist for first access and launch updates.\u201D",
          date: "2026-04-11T22:51:36.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2043094921167434159",
          content: "#47 Gyro Spin Bottle \u2014 Fun simple spin-the-bottle game that uses your device\u2019s gyroscope to spin a 2D glass bottle.",
          date: "2026-04-11T22:32:42.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2043079748822175746",
          content: "#46 Local Business Lead Scanner \u2014 Scan OpenStreetMap business data to find local leads with no website listed.",
          date: "2026-04-11T21:32:25.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2043077129366053204",
          content: "#45 OmniPost \u2014 Create, optimize, and manage posts for all your social media platforms with AI assistance and SEO tools.",
          date: "2026-04-11T21:22:00.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2042984263792947655",
          content: "#44 Nexus 3D Editor \u2014 Lightweight, powerful 3D model loader and editor inspired by Spline and Blender.",
          date: "2026-04-11T15:12:59.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2042982133627547701",
          content: "#43 LinguaBot \u2014 Real-time conversational AI language learning partner.",
          date: "2026-04-11T15:04:32.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2042979946226676020",
          content: "#42 JS Mastery Zero to Hero \u2014 Interactive JavaScript learning platform with micro-steps, bento-grid dashboard, and AI-powered waitlist.",
          date: "2026-04-11T14:55:50.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2042976935446257787",
          content: "#41 Gorilla Funk Skateboards \u2014 High-energy platform for skateboard lessons and tips in Virginia Beach, featuring expert coaching and beginner-friendly guides.",
          date: "2026-04-11T14:43:52.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2042974875959140629",
          content: "#40 Hampton Roads Lawn Care \u2014 10-page SEO-optimized lawn care service website for Hampton Roads, Virginia.",
          date: "2026-04-11T14:35:41.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2042972429975216288",
          content: "#39 Grip & Grime Game of Skate \u2014 The ultimate gritty tracker for your Game of S.K.A.T.E. sessions. Track letters, time turns, and capture the clips.",
          date: "2026-04-11T14:25:58.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2042970131593150904",
          content: "#38 Edge-Forge \u2014 Build and run private AI workflows directly on your device with WebGPU. Targets teams who need local control, speed, and custom skills.",
          date: "2026-04-11T14:16:50.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2042967461964710156",
          content: "#37 DeepSearch AI \u2014 Google-inspired search engine that provides deep analysis, visual graphs, and keyword insights using Gemini AI and Google Search grounding.",
          date: "2026-04-11T14:06:14.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2042964476534673815",
          content: "#36 CertPath \u2014 Canvas-based interactive roadmap for professional certifications across Web, AI, Cyber Security, and more.",
          date: "2026-04-11T13:54:22.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2042847766829748462",
          content: "#35 BuildEstimate AI \u2014 Professional construction estimation tool for residential and commercial projects, powered by AI for deep ROI analysis and cost breakdowns.",
          date: "2026-04-11T06:10:36.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2042819950373445891",
          content: "#34 BudScan AI \u2014 Advanced cannabis quality scanner using multi-stage AI visual analysis to detect PGR, mold, and quality.",
          date: "2026-04-11T04:20:04.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2042817836427464760",
          content: "#33 AI Talk AI Go \u2014 Primitive AI assistant for the modern caveman. Talk to Oog, the world\u2019s first LLM (Large Lithic Model).",
          date: "2026-04-11T04:11:40.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2042815383262937220",
          content: "#32 Aetheris AI Workforce Interfaces \u2014 Next-generation GUI interfaces for orchestrating AI agent employees (Dev, Orchestrator, and Customer views).",
          date: "2026-04-11T04:01:55.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2040889006288703758",
          content: "#31 I Got You \u2014 Premium service provider sponsored by Tech Pro, delivering fast digital support, in-person assistance, and curated resources.",
          date: "2026-04-05T20:27:11.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2040883463549542494",
          content: "#30 HostBuild Directory \u2014 Helps you compare website builders, hosting providers, and cloud platforms for projects across the 757 Hampton Roads region.",
          date: "2026-04-05T20:05:10.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2040837225814888752",
          content: "#29 KitchenForge \u2014 Helps chefs and entrepreneurs launch and scale delivery-first food brands across Hampton Roads, Virginia.",
          date: "2026-04-05T17:01:26.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2040626281029513338",
          content: "#28 AuraAI (Front Desk Agent) \u2014 AI-powered front desk agent for businesses. Replace receptionist overhead with a 24/7 assistant at lower cost.",
          date: "2026-04-05T03:03:13.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2040529148456665518",
          content: "#27 Datamosh Studio \u2014 Web-based video editor for real-time datamoshing, glitch effects, and quick WebM exports in your browser.",
          date: "2026-04-04T20:37:14.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2040522554348130366",
          content: "#26 Procrastinator Pro \u2014 Satire productivity app with an AI Enabler, existential dread meter, and local-first task deferral tracker.",
          date: "2026-04-04T20:11:02.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2040494980578386275",
          content: "#25 SloppyJoes \u2014 Chaotic, community-driven parody platform where people share weird AI-generated content, react with daily-limited votes, and browse a fully branded experience.",
          date: "2026-04-04T18:21:28.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2040482906674475356",
          content: "#24 BrainWidth \u2014 AI-assisted cognitive load planner that helps organize tasks around mental energy and plan sustainable workdays.",
          date: "2026-04-04T17:33:29.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2040478600785236122",
          content: "#23 Simple Portfolio Template \u2014 Portfolio template for anyone looking for a simple digital-themed config-based portfolio.",
          date: "2026-04-04T17:16:23.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2040471523488587916",
          content: "#22 SignalNest \u2014 Helps founders and creators capture sources, score signal quality, and generate rate-limited AI digests.",
          date: "2026-04-04T16:48:15.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2040454961448812701",
          content: "#21 Universal File Converter \u2014 Production-ready universal file converter for Linux cloud environments (including Streamlit Cloud).",
          date: "2026-04-04T15:42:27.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2040230557997510730",
          content: "#20 PackageForge \u2014 AI-powered package generator IDE. Build, iterate, and export production-ready package scaffolds across many languages.",
          date: "2026-04-04T00:50:45.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2039560783168708736",
          content: "#19 AuraMap \u2014 AI-powered map experience that reveals historical + cultural \u201Cechoes\u201D for any location on Earth.",
          date: "2026-04-02T04:29:18.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2039519953980678641",
          content: "#18 Nexus (Agentic API Explorer) \u2014 Agentic API explorer + IDE. API testing that works reliably in production.",
          date: "2026-04-02T01:47:04.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2039482144016249092",
          content: "#17 Cyber Turtle \u2014 Neon arcade web game with voice-powered attacks, synthwave vibes, and fast-paced browser action.",
          date: "2026-04-01T23:16:49.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2038808370996523227",
          content: "#16 AudioCypher \u2014 High-tech cryptographic tool that uses audio files and volume levels as the entropy key to encrypt, decrypt, and hash files.",
          date: "2026-03-31T02:39:29.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2038791078820651392",
          content: "#15 Stoicism Archive \u2014 Comprehensive digital archive of Stoic philosophy featuring quotes, biographies, and spiritual exercises.",
          date: "2026-03-31T01:30:46.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2038787313199690115",
          content: "#14 Thumb Journey \u2014 Mobile-first cinematic audio experience. Hold, motion, and parallax transform iconic speeches into tactile rituals.",
          date: "2026-03-31T01:15:48.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2038446140912181532",
          content: "#13 SF Arcade \u2014 Street Fighter Arcade \u2014 retro competitive arena with real-time multiplayer. Modes: Typing Battle, Code Clash, and Arcade Fight.",
          date: "2026-03-30T02:40:07.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2038382524506767506",
          content: "#12 Melt The Machine \u2014 Anonymous ICE sighting reporting tool and comprehensive \u201CKnow Your Rights\u201D resource hub. Protect your community.",
          date: "2026-03-29T22:27:19.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2038366576378884367",
          content: "#11 Hack The World \u2014 Hacker-styled Hacker News interface with immersive terminal visuals, threaded comments, and live top/new/ask/show/job feeds.",
          date: "2026-03-29T21:23:57.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2038117835092689180",
          content: "#10 Winner Winner Chicken Dinner \u2014 Training-focused blackjack web app for faster card-counting skill development.",
          date: "2026-03-29T04:55:32.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2038031925416214603",
          content: "#9 Conscious Cat Guardianship \u2014 Rescue-first cat care guide covering behavior, nutrition, breeds, and practical day-to-day feline well-being.",
          date: "2026-03-28T23:14:10.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2038019878322377182",
          content: "#8 The Gazette Hub \u2014 High-end, modernized newspaper website template and brand management hub.",
          date: "2026-03-28T22:26:18.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2037722125113467222",
          content: "#7 SEO Trend Tool \u2014 Lightweight keyword opportunity mining from Google Trends, optimized to run on Streamlit Cloud free tier.",
          date: "2026-03-28T02:43:08.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2037710038555385948",
          content: "#6 Lumina \u2014 Helps you design premium websites with ready-made sections, responsive previews, SEO controls, and exportable code.",
          date: "2026-03-28T01:55:06.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2037702073236549770",
          content: "#5 Aether \u2014 Interactive digital consciousness experience \u2014 a highly designed, out-of-the-box web journey.",
          date: "2026-03-28T01:23:27.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2037154018229633054",
          content: "#4 DuckDuckDucky \u2014 Terminal-inspired React-based editor designed for security researchers and hardware enthusiasts. Provides Duck Scripts for inspiration.",
          date: "2026-03-26T13:05:41.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2036576847295553884",
          content: "#3 OneFocus \u2014 Hyper-minimalist daily focus application. Less is more. Focus on one task at a time, eliminate distractions, and boost your productivity.",
          date: "2026-03-24T22:52:12.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2036572320492364125",
          content: "#2 Mundane Oracle \u2014 The everyday app that makes your trivial decisions using absurdly dramatic cosmic reasoning. Made for the overthinker. Built without overthinking.",
          date: "2026-03-24T22:34:13.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2036494051046727791",
          content: "#1 The Con Archive \u2014 A grifter wiki. Capturing historical grifters and cons throughout history.",
          date: "2026-03-24T17:23:12.000Z"
        }
      ]
    },
    {
      id: 2,
      name: "Season 2 (Summer 2026)",
      challenge: {
        title: "100 Websites: Season 2",
        startDate: "2026-07-01T00:00:00Z",
        endDate: "2026-07-30T23:59:59Z",
        targetCount: 100
      },
      projects: [
        {
          id: 1,
          title: "Solana World Map",
          date: "2026-07-01T12:37:00.000Z",
          url: "https://solanaworldmap.netlify.app",
          description: "Interactive Three.js 3D globe tracking live Solana wallets, transactions, and validator activity around the world.",
          tags: [
            "three-js",
            "react",
            "solana",
            "webgl"
          ],
          thumbnail: "https://solanaworldmap.netlify.app/og-image.png"
        },
        {
          id: 2,
          title: "CreatorPlaybooks Mentor Lab",
          date: "2026-07-01T13:48:00.000Z",
          url: "https://creatorplaybooks-mentor-lab.netlify.app",
          description: "Adopt proven creator growth playbooks and schedule daily X execution strategies from verified top creators.",
          tags: [
            "react",
            "vite",
            "marketing",
            "productivity"
          ],
          thumbnail: "https://creatorplaybooks-mentor-lab.netlify.app/og-image.png"
        },
        {
          id: 3,
          title: "Spark a Smile",
          date: "2026-07-01T22:12:00.000Z",
          url: "https://spark-a-smile.netlify.app",
          description: "Need a lift? Talk to smiley and brighten your day with winking 3D characters and custom positive vibes.",
          tags: [
            "react",
            "tailwind",
            "vite",
            "3d"
          ],
          thumbnail: "https://spark-a-smile.netlify.app/og-image.png"
        },
        {
          id: 4,
          title: "Coffee Meet",
          date: "2026-07-01T15:00:00.000Z",
          url: "https://coffee-meetup-neal.netlify.app",
          description: "Book coffee chats that help both people win \u2014 a lightweight networking scheduler for creators and operators.",
          tags: [
            "react",
            "netlify",
            "scheduling"
          ],
          thumbnail: "https://coffee-meetup-neal.netlify.app/og-image.png"
        },
        {
          id: 5,
          title: "A+ Active Services Review",
          date: "2026-07-01T18:00:00.000Z",
          url: "https://jai-aplus-review.netlify.app",
          description: "Compound intelligence factory review page for Jai\u2019s A+ Active Services \u2014 a polished partner-facing summary.",
          tags: [
            "react",
            "review",
            "landing-page"
          ],
          thumbnail: "https://jai-aplus-review.netlify.app/og-image.png"
        },
        {
          id: 6,
          title: "You Are What You Eat",
          date: "2026-07-01T20:00:00.000Z",
          url: "https://you-are-what-you-eat.netlify.app",
          description: "Nutrition and food-awareness micro-app exploring the connection between what you eat and how you feel.",
          tags: [
            "react",
            "health",
            "education"
          ],
          thumbnail: "https://you-are-what-you-eat.netlify.app/og-image.png"
        },
        {
          id: 7,
          title: "Reno Scheduler",
          date: "2026-07-02T10:00:00.000Z",
          url: "https://reisch-scheduler.netlify.app/",
          description: "Simple scheduling and timeline tool for renovators and contractors to manage crew details and trade blocks.",
          tags: [
            "react",
            "tailwind",
            "vite",
            "productivity"
          ],
          thumbnail: "https://reisch-scheduler.netlify.app/og-image.png"
        },
        {
          id: 8,
          title: "Spark Something Cute",
          date: "2026-07-02T12:00:00.000Z",
          url: "https://spark-something-cute.netlify.app",
          description: "Interactive Three.js visual toy that changes based on your unique seed, location, and device tilt coordinates.",
          tags: [
            "three-js",
            "react",
            "vite",
            "webgl"
          ],
          thumbnail: "https://spark-something-cute.netlify.app/og-image.png"
        },
        {
          id: 9,
          title: "Agent Runner Calculator",
          date: "2026-07-02T15:00:00.000Z",
          url: "https://agent-runner-calculator.netlify.app/",
          description: "Calculate credit estimates and API token costs for your AI agent runs before triggering large pipeline tasks.",
          tags: [
            "react",
            "vite",
            "agents",
            "math"
          ],
          thumbnail: "https://agent-runner-calculator.netlify.app/og-image.png"
        },
        {
          id: 10,
          title: "Dogged Studio Daily Timeline",
          date: "2026-07-02T17:00:00.000Z",
          url: "https://daily-timeline-doggedstudio-chaiwithj.netlify.app",
          description: "Daily timeline page built for Dogged Studio and @ChaiWithJai \u2014 track publishing cadence and public build updates.",
          tags: [
            "react",
            "timeline",
            "productivity"
          ],
          thumbnail: "https://daily-timeline-doggedstudio-chaiwithj.netlify.app/og-image.png"
        },
        {
          id: 11,
          title: "Cosmos Flow",
          date: "2026-07-03T10:00:00.000Z",
          url: "https://cosmos-flow.netlify.app",
          description: "Single-page responsive canvas featuring self-healing liquid backgrounds, built entirely on Android via Termux + Hermes Agent.",
          tags: [
            "hermes-agent",
            "javascript",
            "netlify",
            "termux",
            "canvas"
          ],
          thumbnail: "https://cosmos-flow.netlify.app/og-image.png"
        },
        {
          id: 12,
          title: "Data Moshy",
          date: "2026-07-03T15:00:00.000Z",
          url: "https://spark-a-mosh.netlify.app/",
          description: "Interactive media utility applying datamoshing distortions, keyframe color smears, and glitched compression to videos and images.",
          tags: [
            "canvas",
            "datamosh",
            "media",
            "glitch"
          ],
          thumbnail: "https://spark-a-mosh.netlify.app/og-image.png"
        },
        {
          id: 13,
          title: "Dimension Lab",
          date: "2026-07-04T12:00:00.000Z",
          url: "https://spark-a-dimension.netlify.app/",
          description: "Visualize and compare the differences between 2D and 3D design elements, parameters, and browser rendering capabilities.",
          tags: [
            "three-js",
            "webgl",
            "design",
            "3d"
          ],
          thumbnail: "https://spark-a-dimension.netlify.app/og-image.png"
        },
        {
          id: 14,
          title: "Whimsical Wonderland",
          date: "2026-07-05T10:00:00.000Z",
          url: "https://spark-a-wonderland.netlify.app",
          description: "The Garden of Happy Nonsense \u2014 a playful interactive scene of whimsical visuals and lighthearted browser magic.",
          tags: [
            "react",
            "three-js",
            "interactive",
            "creative"
          ],
          thumbnail: "https://spark-a-wonderland.netlify.app/og-image.png"
        },
        {
          id: 15,
          title: "Netlify Agent Runner",
          date: "2026-07-05T14:00:00.000Z",
          url: "https://ar-gui.netlify.app",
          description: "Sci-fi-grade dashboard to manage your Netlify Agent Runners from one central console.",
          tags: [
            "react",
            "netlify",
            "agents",
            "dashboard"
          ],
          thumbnail: "https://ar-gui.netlify.app/og-image.png"
        },
        {
          id: 16,
          title: "CreatorPlaybooks System Pass",
          date: "2026-07-06T12:00:00.000Z",
          url: "https://creatorplaybooks.netlify.app/x-today.html",
          description: "System pass of the Virtual Mentor Lab: removes automation friction, standardizes prompts, and implements full cross-day navigation.",
          tags: [
            "react",
            "vite",
            "productivity",
            "workflow"
          ],
          thumbnail: "https://creatorplaybooks.netlify.app/og-image.png"
        },
        {
          id: 17,
          title: "Netlify Agent Runner Console",
          date: "2026-07-06T16:00:00.000Z",
          url: "https://ar-gui.netlify.app",
          description: "Hardened Netlify Agent Runner console with full GUI controls, runner status, and deployment orchestration.",
          tags: [
            "react",
            "netlify",
            "agents",
            "dashboard"
          ],
          thumbnail: "https://ar-gui.netlify.app/og-image.png"
        },
        {
          id: 18,
          title: "CreatorPlaybooks Virtual Mentor Lab",
          date: "2026-07-07T12:00:00.000Z",
          url: "https://creatorplaybooks.netlify.app/",
          description: "Wire live API data to load all 13 mentors, render real cover art dynamically, and add an animated canvas fallback to keep media active.",
          tags: [
            "react",
            "api",
            "three-js",
            "marketing"
          ],
          thumbnail: "https://creatorplaybooks.netlify.app/og-image.png"
        },
        {
          id: 19,
          title: "LunaWebGPU",
          date: "2026-07-07T14:00:00.000Z",
          url: "https://spark-a-moon.netlify.app",
          description: "Interactive 3D moon phase visualizer powered by WebGPU, showing lunar cycles with real-time lighting and controls.",
          tags: [
            "webgpu",
            "three-js",
            "react",
            "space"
          ],
          thumbnail: "https://spark-a-moon.netlify.app/og-image.png"
        },
        {
          id: 20,
          title: "SolPay",
          date: "2026-07-07T16:00:00.000Z",
          url: "https://noahai-6a4d343b404ae31e410012a0.netlify.app",
          description: "Get paid in SOL \u2014 a simple Solana payment request and checkout flow for creators and freelancers.",
          tags: [
            "solana",
            "payments",
            "react",
            "web3"
          ],
          thumbnail: "https://noahai-6a4d343b404ae31e410012a0.netlify.app/og-image.png"
        },
        {
          id: 21,
          title: "CreatorPlaybooks Feedback Loops",
          date: "2026-07-08T10:00:00.000Z",
          url: "https://creatorplaybooks.netlify.app/day7.html",
          description: "Glassmorphic user feedback collection widget saving mock submissions to localStorage and updating live dashboard stats.",
          tags: [
            "react",
            "css",
            "localStorage",
            "ux"
          ],
          thumbnail: "https://creatorplaybooks.netlify.app/og-image.png"
        },
        {
          id: 22,
          title: "Matrix Rain Chamber",
          date: "2026-07-08T03:07:00.000Z",
          url: "https://spark-a-matrix.netlify.app",
          description: "Three.js WebGPU-first Matrix fan scene with procedural digital rain and stylized Neo, Morpheus, and Trinity figures.",
          tags: [
            "three-js",
            "webgpu",
            "canvas",
            "game",
            "retro"
          ],
          thumbnail: "https://spark-a-matrix.netlify.app/og-image.png"
        },
        {
          id: 23,
          title: "Matrix Vector Live Decoder",
          date: "2026-07-08T12:00:00.000Z",
          url: "https://spark-a-matrix-feed.netlify.app",
          description: "Live decoder feed for Matrix vector streams \u2014 visualize cascading code signals and encoded payloads in real time.",
          tags: [
            "javascript",
            "canvas",
            "matrix",
            "retro"
          ],
          thumbnail: "https://spark-a-matrix-feed.netlify.app/og-image.png"
        },
        {
          id: 24,
          title: "VectorCam",
          date: "2026-07-08T14:00:00.000Z",
          url: "https://tubular-taffy-6dd846.netlify.app",
          description: "Insane Three.js video effects camera \u2014 apply real-time vector shaders and 3D distortions to your webcam feed.",
          tags: [
            "three-js",
            "webgl",
            "camera",
            "video"
          ],
          thumbnail: "https://tubular-taffy-6dd846.netlify.app/og-image.png"
        },
        {
          id: 25,
          title: "Agent Loom",
          date: "2026-07-08T16:00:00.000Z",
          url: "https://agent-loom.netlify.app",
          description: "Weave together multiple AI agent threads into a single orchestrated execution loom.",
          tags: [
            "react",
            "agents",
            "orchestration",
            "ai"
          ],
          thumbnail: "https://agent-loom.netlify.app/og-image.png"
        }
      ],
      socialPosts: [
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2048564021239842810",
          content: "Season 2 Day 0: Solana World Map is live. Interactive Three.js 3D globe tracking live Solana wallets, transactions, and validator activity around the world.",
          date: "2026-07-01T12:37:00.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2048564021239842811",
          content: "Season 2 Day 0: CreatorPlaybooks Mentor Lab is live. Adopt proven creator growth playbooks and schedule daily X execution strategies from verified top creators.",
          date: "2026-07-01T13:48:00.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2048564021239842812",
          content: "Season 2 Day 0: Spark a Smile is live. Need a lift? Talk to smiley and brighten your day with winking 3D characters and custom positive vibes.",
          date: "2026-07-01T22:12:00.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2048564021239842813",
          content: "Season 2 Day 0: Coffee Meet is live. Book coffee chats that help both people win \u2014 a lightweight networking scheduler for creators and operators.",
          date: "2026-07-01T15:00:00.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2048564021239842814",
          content: "Season 2 Day 0: A+ Active Services Review is live. Compound intelligence factory review page for Jai\u2019s A+ Active Services \u2014 a polished partner-facing summary.",
          date: "2026-07-01T18:00:00.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2048564021239842815",
          content: "Season 2 Day 0: You Are What You Eat is live. Nutrition and food-awareness micro-app exploring the connection between what you eat and how you feel.",
          date: "2026-07-01T20:00:00.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2048564021239842816",
          content: "Season 2 Day 1: Reno Scheduler is live. Simple scheduling and timeline tool for renovators and contractors to manage crew details and trade blocks.",
          date: "2026-07-02T10:00:00.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2048564021239842817",
          content: "Season 2 Day 1: Spark Something Cute is live. Interactive Three.js visual toy that changes based on your unique seed, location, and device tilt coordinates.",
          date: "2026-07-02T12:00:00.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2048564021239842818",
          content: "Season 2 Day 1: Agent Runner Calculator is live. Calculate credit estimates and API token costs for your AI agent runs before triggering large pipeline tasks.",
          date: "2026-07-02T15:00:00.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2048564021239842819",
          content: "Season 2 Day 1: Dogged Studio Daily Timeline is live. Daily timeline page built for Dogged Studio and @ChaiWithJai \u2014 track publishing cadence and public build updates.",
          date: "2026-07-02T17:00:00.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2048564021239842820",
          content: "Season 2 Day 2: Cosmos Flow is live. Single-page responsive canvas featuring self-healing liquid backgrounds, built entirely on Android via Termux + Hermes Agent.",
          date: "2026-07-03T10:00:00.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2048564021239842821",
          content: "Season 2 Day 2: Data Moshy is live. Interactive media utility applying datamoshing distortions, keyframe color smears, and glitched compression to videos and images.",
          date: "2026-07-03T15:00:00.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2048564021239842822",
          content: "Season 2 Day 3: Dimension Lab is live. Visualize and compare the differences between 2D and 3D design elements, parameters, and browser rendering capabilities.",
          date: "2026-07-04T12:00:00.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2048564021239842823",
          content: "Season 2 Day 4: Whimsical Wonderland is live. The Garden of Happy Nonsense \u2014 a playful interactive scene of whimsical visuals and lighthearted browser magic.",
          date: "2026-07-05T10:00:00.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2048564021239842824",
          content: "Season 2 Day 4: Netlify Agent Runner is live. Sci-fi-grade dashboard to manage your Netlify Agent Runners from one central console.",
          date: "2026-07-05T14:00:00.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2048564021239842825",
          content: "Season 2 Day 5: CreatorPlaybooks System Pass is live. System pass of the Virtual Mentor Lab: removes automation friction, standardizes prompts, and implements full cross-day navigation.",
          date: "2026-07-06T12:00:00.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2048564021239842826",
          content: "Season 2 Day 5: Netlify Agent Runner Console is live. Hardened Netlify Agent Runner console with full GUI controls, runner status, and deployment orchestration.",
          date: "2026-07-06T16:00:00.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2048564021239842827",
          content: "Season 2 Day 6: CreatorPlaybooks Virtual Mentor Lab is live. Wire live API data to load all 13 mentors, render real cover art dynamically, and add an animated canvas fallback to keep media active.",
          date: "2026-07-07T12:00:00.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2048564021239842828",
          content: "Season 2 Day 6: LunaWebGPU is live. Interactive 3D moon phase visualizer powered by WebGPU, showing lunar cycles with real-time lighting and controls.",
          date: "2026-07-07T14:00:00.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2048564021239842829",
          content: "Season 2 Day 6: SolPay is live. Get paid in SOL \u2014 a simple Solana payment request and checkout flow for creators and freelancers.",
          date: "2026-07-07T16:00:00.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2048564021239842830",
          content: "Season 2 Day 7: CreatorPlaybooks Feedback Loops is live. Glassmorphic user feedback collection widget saving mock submissions to localStorage and updating live dashboard stats.",
          date: "2026-07-08T10:00:00.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2048564021239842831",
          content: "Season 2 Day 7: Matrix Rain Chamber is live. Three.js WebGPU-first Matrix fan scene with procedural digital rain and stylized Neo, Morpheus, and Trinity figures.",
          date: "2026-07-08T03:07:00.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2048564021239842832",
          content: "Season 2 Day 7: Matrix Vector Live Decoder is live. Live decoder feed for Matrix vector streams \u2014 visualize cascading code signals and encoded payloads in real time.",
          date: "2026-07-08T12:00:00.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2048564021239842833",
          content: "Season 2 Day 7: VectorCam is live. Insane Three.js video effects camera \u2014 apply real-time vector shaders and 3D distortions to your webcam feed.",
          date: "2026-07-08T14:00:00.000Z"
        },
        {
          platform: "X",
          url: "https://x.com/NealFrazierTech/status/2048564021239842834",
          content: "Season 2 Day 7: Agent Loom is live. Weave together multiple AI agent threads into a single orchestrated execution loom.",
          date: "2026-07-08T16:00:00.000Z"
        }
      ]
    }
  ]
};

// netlify/functions/api.ts
var data = challenge_config_default;
var handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Content-Type": "application/json; charset=utf-8"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: ""
    };
  }
  let path = event.path.replace(/^\/api\/?/, "").toLowerCase();
  path = path.replace(/\/+$/, "");
  const params = event.queryStringParameters || {};
  const seasonParam = params.season ? parseInt(params.season, 10) : null;
  const searchParam = params.search ? params.search.toLowerCase() : null;
  const limitParam = params.limit ? parseInt(params.limit, 10) : null;
  const formatParam = params.format ? params.format.toLowerCase() : "json";
  const respond = (bodyData, markdownFormatter) => {
    if (formatParam === "markdown" || formatParam === "md" || formatParam === "text" || formatParam === "txt") {
      return {
        statusCode: 200,
        headers: {
          ...headers,
          "Content-Type": "text/markdown; charset=utf-8"
        },
        body: markdownFormatter()
      };
    }
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(bodyData, null, 2)
    };
  };
  if (path === "seasons") {
    const seasonsList = data.seasons.map((s) => ({
      id: s.id,
      name: s.name,
      title: s.challenge.title,
      startDate: s.challenge.startDate,
      endDate: s.challenge.endDate,
      targetCount: s.challenge.targetCount,
      projectCount: s.projects.length,
      postCount: s.socialPosts.length
    }));
    return respond(seasonsList, () => {
      let md = `# Seasons of ${data.seasons[0].challenge.title}

`;
      seasonsList.forEach((s) => {
        md += `## Season ${s.id}: ${s.name}
`;
        md += `- **Challenge**: ${s.title}
`;
        md += `- **Timeline**: ${s.startDate.split("T")[0]} to ${s.endDate.split("T")[0]}
`;
        md += `- **Progress**: ${s.projectCount} / ${s.targetCount} projects shipped
`;
        md += `- **Social Updates**: ${s.postCount} posts logged

`;
      });
      return md;
    });
  }
  if (path === "projects") {
    let filteredProjects = [];
    data.seasons.forEach((s) => {
      if (seasonParam !== null && s.id !== seasonParam) return;
      s.projects.forEach((p) => {
        if (searchParam) {
          const matchTitle = p.title.toLowerCase().includes(searchParam);
          const matchDesc = p.description.toLowerCase().includes(searchParam);
          const matchTags = p.tags.some((t) => t.toLowerCase().includes(searchParam));
          if (!matchTitle && !matchDesc && !matchTags) return;
        }
        filteredProjects.push({
          ...p,
          seasonId: s.id,
          seasonName: s.name
        });
      });
    });
    filteredProjects.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    if (limitParam !== null) {
      filteredProjects = filteredProjects.slice(0, limitParam);
    }
    return respond(filteredProjects, () => {
      let md = `# Shipped Projects (${filteredProjects.length} found)

`;
      filteredProjects.forEach((p) => {
        md += `### ${p.title}
`;
        md += `- **Season**: ${p.seasonName} (Season ${p.seasonId})
`;
        md += `- **Date Shipped**: ${p.date.split("T")[0]}
`;
        md += `- **URL**: [${p.url}](${p.url})
`;
        md += `- **Description**: ${p.description}
`;
        md += `- **Tags**: ${p.tags.map((t) => `\`${t}\``).join(", ")}

`;
      });
      return md;
    });
  }
  if (path === "feed" || path === "posts") {
    let filteredPosts = [];
    data.seasons.forEach((s) => {
      if (seasonParam !== null && s.id !== seasonParam) return;
      s.socialPosts.forEach((post) => {
        if (searchParam) {
          if (!post.content.toLowerCase().includes(searchParam)) return;
        }
        filteredPosts.push({
          ...post,
          seasonId: s.id,
          seasonName: s.name
        });
      });
    });
    filteredPosts.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    if (limitParam !== null) {
      filteredPosts = filteredPosts.slice(0, limitParam);
    }
    return respond(filteredPosts, () => {
      let md = `# Build Feed Updates (${filteredPosts.length} posts)

`;
      filteredPosts.forEach((post) => {
        md += `### Post on ${post.date.split("T")[0]} (${post.platform})
`;
        md += `> ${post.content}

`;
        md += `[View original post](${post.url})

---

`;
      });
      return md;
    });
  }
  const stats = {
    title: data.seasons[0].challenge.title,
    seasonsCount: data.seasons.length,
    totalProjectsCount: data.seasons.reduce((acc, s) => acc + s.projects.length, 0),
    totalPostsCount: data.seasons.reduce((acc, s) => acc + s.socialPosts.length, 0),
    endpoints: [
      { path: "/api/seasons", description: "List of seasons with timeline dates, project statistics, and goals." },
      { path: "/api/projects", description: "All shipped websites. Supports ?season=2, ?search=canvas, ?limit=5, & ?format=markdown." },
      { path: "/api/feed", description: "Chronological timeline of social media posts, build announcements, and deployments." }
    ]
  };
  return respond(stats, () => {
    let md = `# 100 Websites in 30 Days API
`;
    md += `Welcome to the developer & AI Agent API for Neal Frazier's 100 Websites Challenge.

`;
    md += `## Challenge Stats
`;
    md += `- **Challenge**: ${stats.title}
`;
    md += `- **Seasons**: ${stats.seasonsCount}
`;
    md += `- **Total Shipped**: ${stats.totalProjectsCount} projects
`;
    md += `- **Total Social Updates**: ${stats.totalPostsCount} posts

`;
    md += `## Available Endpoints

`;
    stats.endpoints.forEach((e) => {
      md += `### \`GET ${e.path}\`
`;
      md += `${e.description}

`;
    });
    md += `## AI / Agent Integrations
`;
    md += `If you are fetching this from an AI model or curl terminal, append \`?format=markdown\` or \`?format=txt\` to any endpoint to receive a clean, readable Markdown structure instead of JSON.

`;
    md += `### Curl Example
`;
    md += `\`\`\`bash
`;
    md += `curl "https://100websitesin30days.nealfrazier.tech/api/projects?season=2&format=markdown"
`;
    md += `\`\`\`
`;
    return md;
  });
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
